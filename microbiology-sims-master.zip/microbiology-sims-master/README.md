# microbiology-sims
微生物学虚拟仿真实验平台
🔬 乐山师范学院 · 微生物学实验教学辅助平台
📖 项目简介
本平台是一个面向高校微生物学教学的虚拟仿真实验系统，通过 Web 技术模拟真实实验环境，帮助学生：
- ✅ 理解微生物实验的标准操作流程
- ✅ 降低实验材料消耗和安全风险
- ✅ 随时随地进行实验预习和复习
- ✅ 提供可视化、交互式的的学习体验
🎯 功能特点
功能  说明
🧪 虚拟实验操作  模拟真实实验步骤和仪器使用 📋 实验步骤引导  逐步提示，规范操作流程 📊 实验结果可视化  直观展示实验现象和数据 📈 学习进度跟踪  记录学习轨迹和完成情况 📱 多终端适配  支持电脑、平板、手机访问
📚 实验模块
模块一：培养基制备
- 配方计算与称量
- 溶解与调节 pH 值
- 分装与灭菌操作
模块二：微生物接种技术
- 无菌操作规范
- 斜面接种模拟
- 平板划线操作
模块三：显微镜观察
- 显微镜使用方法
- 染色标本观察
- 微生物形态识别
模块四：菌落计数与分析
- 平板菌落计数
- 数据统计与分析
- 实验报告生成
🚀 快速开始
在线访问 Gitee Pages 部署后填写网址
本地运行bash
1. 克隆项目
git clone https://gitee.com/dreamer9888/microbiology-sims.git
2. 进入项目目录
cd microbiology-sims
3. 直接用浏览器打开 index.html
🛠️ 技术栈
技术  用途
HTML5  页面结构 CSS3  样式与布局 JavaScript  交互逻辑 Canvas/SVG  实验图形绘制
📁 项目结构 microbiology-sims/ ├── index.html          # 首页入口 ├── css/                # 样式文件 │   └── style.css ├── js/                 # 脚本文件 │   └── main.js ├── images/             # 图片资源 └── README.md           # 项目说明
📝 更新日志
- 2025-07-23 - 项目初始化，创建基础框架
- 🔄 持续更新中...
🤝 贡献指南
欢迎老师和同学们参与改进！
1. Fork 本项目
2. 创建新分支 (git checkout -b feature/AmazingFeature)
3. 提交更改 (git commit -m 'Add some AmazingFeature')
4. 推送到分支 (git push origin feature/AmazingFeature)
5. 开启 Pull Request
📄 许可证
MIT License
📧 联系方式
- 作者: 追梦人
- 学校: 乐山师范学院
- 邮箱: [gongmingfu98@163.com]
<div align="center">
🎓 仅供教学使用 · 欢迎交流反馈
</div>